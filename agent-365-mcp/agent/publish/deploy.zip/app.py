# app.py
"""
Simple Agent 365 agent that echoes user messages.
This is a static agent that doesn't use any LLM - it simply responds with 
"Hello, this is your agent! You said: <user message>"
"""

import sys
import traceback
from os import environ
from dotenv import load_dotenv
from microsoft_agents.hosting.core import (
    AgentApplication,
    TurnState,
    TurnContext,
    MemoryStorage,
    Authorization,
)
from microsoft_agents.hosting.aiohttp import CloudAdapter
from microsoft_agents.authentication.msal import MsalConnectionManager
from microsoft_agents.activity import load_configuration_from_env
from start_server import start_server

# Load environment variables from .env file
load_dotenv()

# Load SDK configuration from environment variables
agents_sdk_config = load_configuration_from_env(environ)

# Create storage, connection manager, adapter, and authorization
STORAGE = MemoryStorage()
CONNECTION_MANAGER = MsalConnectionManager(**agents_sdk_config)
ADAPTER = CloudAdapter(connection_manager=CONNECTION_MANAGER)
AUTHORIZATION = Authorization(STORAGE, CONNECTION_MANAGER, **agents_sdk_config)

# Create the Agent Application
AGENT_APP = AgentApplication[TurnState](
    storage=STORAGE, 
    adapter=ADAPTER,
    authorization=AUTHORIZATION,
    **agents_sdk_config
)


@AGENT_APP.conversation_update("membersAdded")
async def on_members_added(context: TurnContext, _state: TurnState):
    """Send a welcome message when the bot joins a conversation."""
    await context.send_activity(
        "👋 Welcome! I'm a simple Agent 365 agent. "
        "Send me any message and I'll echo it back to you. "
        "Type /help for more information."
    )
    return True


@AGENT_APP.message("/help")
async def on_help(context: TurnContext, _state: TurnState):
    """Send help information."""
    await context.send_activity(
        "🤖 **Agent 365 Simple Agent**\n\n"
        "I'm a basic echo agent built with the Microsoft 365 Agents SDK.\n\n"
        "**Commands:**\n"
        "• `/help` - Show this help message\n"
        "• Any other message - I'll echo it back to you!\n\n"
        "This agent demonstrates the basic structure of an Agent 365 agent."
    )


@AGENT_APP.activity("message")
async def on_message(context: TurnContext, _state: TurnState):
    """Handle incoming messages - echo them back with a friendly prefix."""
    user_text = context.activity.text or ""
    
    # Echo the message back
    response = f"Hello, this is your agent! You said: {user_text}"
    await context.send_activity(response)


@AGENT_APP.error
async def on_error(context: TurnContext, error: Exception):
    """Handle errors."""
    print(f"\n [on_turn_error] unhandled error: {error}", file=sys.stderr)
    traceback.print_exc()
    await context.send_activity("The bot encountered an error or bug.")


if __name__ == "__main__":
    try:
        print("🚀 Starting Agent 365 Simple Agent...")
        # Get auth configuration from connection manager
        auth_config = CONNECTION_MANAGER.get_default_connection_configuration()
        start_server(AGENT_APP, auth_config)
    except Exception as error:
        print(f"❌ Error starting agent: {error}")
        raise error
